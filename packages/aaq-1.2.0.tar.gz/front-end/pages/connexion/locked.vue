<template>
  <section class="container">
    <div class="mb-5 mt-5 text-center">
      <h1>
        Vous n’êtes pas autorisé(e) à accéder à l’outil.<br><br>
        Pour toutes questions, veuillez adresser un courriel à<br> AAQ@sports.gouv.fr
      </h1>
    </div>
  </section>
</template>
