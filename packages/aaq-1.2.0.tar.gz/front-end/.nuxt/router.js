import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _2f7a03bd = () => interopDefault(import('../pages/accueil/index.vue' /* webpackChunkName: "pages/accueil/index" */))
const _be9dc5d0 = () => interopDefault(import('../pages/admin/index.vue' /* webpackChunkName: "pages/admin/index" */))
const _2c7c0b98 = () => interopDefault(import('../pages/formateur/index.vue' /* webpackChunkName: "pages/formateur/index" */))
const _4099f405 = () => interopDefault(import('../pages/interventions/index.vue' /* webpackChunkName: "pages/interventions/index" */))
const _26e6d4df = () => interopDefault(import('../pages/mot-de-passe-oublie/index.vue' /* webpackChunkName: "pages/mot-de-passe-oublie/index" */))
const _306dfd76 = () => interopDefault(import('../pages/pageenconstruction/index.vue' /* webpackChunkName: "pages/pageenconstruction/index" */))
const _254b4838 = () => interopDefault(import('../pages/partenaire/index.vue' /* webpackChunkName: "pages/partenaire/index" */))
const _7044c05e = () => interopDefault(import('../pages/proprietaire/index.vue' /* webpackChunkName: "pages/proprietaire/index" */))
const _cc080460 = () => interopDefault(import('../pages/register/index.vue' /* webpackChunkName: "pages/register/index" */))
const _ba19afa6 = () => interopDefault(import('../pages/structureref/index.vue' /* webpackChunkName: "pages/structureref/index" */))
const _584c89d0 = () => interopDefault(import('../pages/connexion/inscription.vue' /* webpackChunkName: "pages/connexion/inscription" */))
const _8342620c = () => interopDefault(import('../pages/connexion/locked.vue' /* webpackChunkName: "pages/connexion/locked" */))
const _10891c29 = () => interopDefault(import('../pages/connexion/login.vue' /* webpackChunkName: "pages/connexion/login" */))
const _4dab717a = () => interopDefault(import('../pages/connexion/logout.vue' /* webpackChunkName: "pages/connexion/logout" */))
const _29a4f12c = () => interopDefault(import('../pages/connexion/profil.vue' /* webpackChunkName: "pages/connexion/profil" */))
const _60ad7a48 = () => interopDefault(import('../pages/mot-de-passe-oublie/reset.vue' /* webpackChunkName: "pages/mot-de-passe-oublie/reset" */))
const _ec412646 = () => interopDefault(import('../pages/validate/_pwd.vue' /* webpackChunkName: "pages/validate/_pwd" */))
const _2dfb1658 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/accueil",
    component: _2f7a03bd,
    name: "accueil"
  }, {
    path: "/admin",
    component: _be9dc5d0,
    name: "admin"
  }, {
    path: "/formateur",
    component: _2c7c0b98,
    name: "formateur"
  }, {
    path: "/interventions",
    component: _4099f405,
    name: "interventions"
  }, {
    path: "/mot-de-passe-oublie",
    component: _26e6d4df,
    name: "mot-de-passe-oublie"
  }, {
    path: "/pageenconstruction",
    component: _306dfd76,
    name: "pageenconstruction"
  }, {
    path: "/partenaire",
    component: _254b4838,
    name: "partenaire"
  }, {
    path: "/proprietaire",
    component: _7044c05e,
    name: "proprietaire"
  }, {
    path: "/register",
    component: _cc080460,
    name: "register"
  }, {
    path: "/structureref",
    component: _ba19afa6,
    name: "structureref"
  }, {
    path: "/connexion/inscription",
    component: _584c89d0,
    name: "connexion-inscription"
  }, {
    path: "/connexion/locked",
    component: _8342620c,
    name: "connexion-locked"
  }, {
    path: "/connexion/login",
    component: _10891c29,
    name: "connexion-login"
  }, {
    path: "/connexion/logout",
    component: _4dab717a,
    name: "connexion-logout"
  }, {
    path: "/connexion/profil",
    component: _29a4f12c,
    name: "connexion-profil"
  }, {
    path: "/mot-de-passe-oublie/reset",
    component: _60ad7a48,
    name: "mot-de-passe-oublie-reset"
  }, {
    path: "/validate/:pwd?",
    component: _ec412646,
    name: "validate-pwd"
  }, {
    path: "/",
    component: _2dfb1658,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
